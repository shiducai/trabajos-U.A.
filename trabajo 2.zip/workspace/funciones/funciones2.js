function posiciones(g){
            
          switch(g){
              case 1:
                   posxI=260;
                   posYI=380;
                   limX_b =251;
                   limX_a =265;
                   limY_b =293;
                   limY_a =427;
                   break;
               case 2:
                   posxI=635;
                   posYI=255;
                   limX_b =600;
                   limX_a =667;
                   limY_b =249;
                   limY_a =260;
                   break;
               case 3:
                   posxI=300;
                   posYI=770;
                   limX_b =211;
                   limX_a =353;
                   limY_b =759;
                   limY_a =781;
                     break;
               case 4:
                   posxI=180;
                   posYI=460;
                   limX_b =93;
                   limX_a =235;
                   limY_b =445;
                   limY_a =469;
                     break;
               case 5:
                   posxI=770;
                   posYI=530;
                   limX_b =721;
                   limX_a =747;
                   limY_b =485;
                   limY_a =585;
                     break;
               case 6:
                   posxI=700;
                   posYI=140;
                   limX_b =643;
                   limX_a =785;
                   limY_b =133;
                   limY_a =153;
                    break;
               case 7:
                   posxI=350;
                   posYI=180;
                   limX_b =211;
                   limX_a =547;
                   limY_b =171;
                   limY_a =199;
                    break;
                case 8:
                   posxI=20;
                   posYI=400;
                   limX_b =13;
                   limX_a =39;
                   limY_b =251;
                   limY_a =665;
                     break;
               case 9:
                   posxI=130;
                   posYI=200;
                   limX_b =121;
                   limX_a =155;
                   limY_b =175;
                   limY_a =351;
                    break;
               case 0:
                   posxI=550;
                   posYI=377;
                   limX_b =525;
                   limX_a =627;
                   limY_b =367;
                   limY_a =387;
                    break;  
                default:
                 posxI=260;
                 posYI=377;
                 break;
                
              
          }  
            
            
            
            
            }